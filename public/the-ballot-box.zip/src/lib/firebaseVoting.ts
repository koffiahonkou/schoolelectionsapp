import {
  collection,
  doc,
  setDoc,
  updateDoc,
  getDocs,
  getDoc,
  getDocFromCache,
  onSnapshot,
  query,
  orderBy,
  Unsubscribe,
  writeBatch,
} from 'firebase/firestore';
import { db, FIREBASE_PROJECT_ID, FIRESTORE_DB_ID } from './firebase';
import { Ballot, Voter, ElectionData, ElectionStatus } from '../types';

export { FIREBASE_PROJECT_ID, FIRESTORE_DB_ID };

export interface AgentObserverRecord {
  id: string;
  agentName: string;
  representedCandidate: string;
  role: 'Candidate Agent' | 'Independent Observer' | 'Electoral Commission Monitor';
  status: 'online' | 'observing' | 'offline';
  lastHeartbeat: string;
  station: string;
  notes?: string;
}

export interface VoterTokenRecord {
  id: string;
  voterId: string;
  token: string;
  fullName: string;
  hasVoted: boolean;
  votedAt: string | null;
  status: 'active' | 'used' | 'revoked';
  issuedAt: string;
}

/**
 * Persists an anonymous cast ballot to Firestore.
 * CRITICAL SECRET BALLOT GUARANTEE:
 * Does NOT write studentId, voterId, studentName, or IP address into the ballot document.
 */
export async function saveAnonymousVoteToFirestore(ballot: Ballot): Promise<boolean> {
  try {
    const ballotRef = doc(db, 'votes', ballot.id);
    const votePayload = {
      id: ballot.id,
      choices: ballot.choices || {},
      submittedAt: ballot.submittedAt || new Date().toISOString(),
      isPractice: !!ballot.isPractice,
      evidenceHash: ballot.evidenceHash || null,
      clientTimestamp: Date.now(),
    };

    await setDoc(ballotRef, votePayload);
    return true;
  } catch (error) {
    console.error('[Firebase] Failed to save anonymous vote to Firestore:', error);
    return false;
  }
}

/**
 * Checks in real-time whether a voter token exists and whether it has already been used to cast a ballot.
 */
export async function checkVoterTokenInFirestore(
  voterId: string
): Promise<{
  exists: boolean;
  hasVoted: boolean;
  votedAt: string | null;
  pin?: string;
}> {
  try {
    const cleanId = voterId.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '_');
    const tokenRef = doc(db, 'voter_tokens', `token-${cleanId}`);
    const tokenTask = getDoc(tokenRef);
    const snap = await withTimeout(tokenTask, 2500, null);

    if (snap && snap.exists()) {
      const data = snap.data();
      return {
        exists: true,
        hasVoted: Boolean(data.hasVoted || data.status === 'used'),
        votedAt: data.votedAt || null,
        pin: data.token,
      };
    }

    // Fallback: Check election_metadata current roster in case tokens collection was not populated
    try {
      const metaRef = doc(db, 'election_metadata', 'current');
      const metaSnap = await withTimeout(getDoc(metaRef), 2000, null);
      if (metaSnap && metaSnap.exists()) {
        const meta = metaSnap.data();
        const found = (meta.voters || []).find(
          (v: any) => v.voterId?.trim().toUpperCase() === cleanId
        );
        if (found) {
          return {
            exists: true,
            hasVoted: Boolean(found.hasVoted),
            votedAt: found.votedAt || null,
            pin: found.pin,
          };
        }
      }
    } catch {
      // ignore
    }
  } catch (error) {
    console.warn('[Firebase] Could not verify voter token in Firestore:', error);
  }
  return { exists: false, hasVoted: false, votedAt: null };
}

/**
 * Updates a voter's token in Firestore to mark them as having cast their ballot.
 */
export async function markVoterTokenUsedInFirestore(
  voterId: string,
  votedAt?: string
): Promise<boolean> {
  try {
    const cleanId = voterId.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '_');
    const tokenRef = doc(db, 'voter_tokens', `token-${cleanId}`);

    const updateData = {
      id: `token-${cleanId}`,
      voterId: voterId.trim().toUpperCase(),
      hasVoted: true,
      votedAt: votedAt || new Date().toISOString(),
      status: 'used' as const,
    };

    // Use atomic merge set so it always succeeds whether document existed or not
    const setTask = setDoc(tokenRef, updateData, { merge: true });
    await withTimeout(setTask, 2500, null);

    // Also update election_metadata/current roster so all devices see the vote on the roster
    try {
      const metaRef = doc(db, 'election_metadata', 'current');
      const metaSnap = await withTimeout(getDoc(metaRef), 2000, null);
      if (metaSnap && metaSnap.exists()) {
        const meta = metaSnap.data();
        if (Array.isArray(meta.voters)) {
          const updatedVoters = meta.voters.map((v: any) =>
            v.voterId.trim().toUpperCase() === voterId.trim().toUpperCase()
              ? { ...v, hasVoted: true, votedAt: updateData.votedAt }
              : v
          );
          const updateTask = updateDoc(metaRef, { voters: updatedVoters, lastUpdated: new Date().toISOString() });
          await withTimeout(updateTask, 2000, null);
        }
      }
    } catch (metaErr) {
      console.warn('[Firebase] Non-fatal metadata voter flag sync warning:', metaErr);
    }

    return true;
  } catch (error) {
    console.error('[Firebase] Failed to update voter token in Firestore:', error);
    return false;
  }
}

/**
 * Resets a single voter's token status in Firestore back to active/unvoted (Admin authorized).
 */
export async function resetVoterTokenInFirestore(voterId: string): Promise<boolean> {
  try {
    const cleanId = voterId.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '_');
    const tokenRef = doc(db, 'voter_tokens', `token-${cleanId}`);
    const setTask = setDoc(
      tokenRef,
      {
        hasVoted: false,
        votedAt: null,
        status: 'active' as const,
      },
      { merge: true }
    );
    await withTimeout(setTask, 2500, null);

    // Also reset in election_metadata
    try {
      const metaRef = doc(db, 'election_metadata', 'current');
      const metaSnap = await withTimeout(getDoc(metaRef), 2000, null);
      if (metaSnap && metaSnap.exists()) {
        const meta = metaSnap.data();
        if (Array.isArray(meta.voters)) {
          const updatedVoters = meta.voters.map((v: any) =>
            v.voterId.trim().toUpperCase() === voterId.trim().toUpperCase()
              ? { ...v, hasVoted: false, votedAt: null }
              : v
          );
          const updateTask = updateDoc(metaRef, { voters: updatedVoters, lastUpdated: new Date().toISOString() });
          await withTimeout(updateTask, 2000, null);
        }
      }
    } catch {
      // ignore
    }
    return true;
  } catch (err) {
    console.warn('[Firebase] Could not reset voter token in Firestore:', err);
    return false;
  }
}

/**
 * Syncs the entire voter roster into Firestore voter_tokens collection.
 */
export async function syncVoterRosterToFirestoreTokens(
  voters: Voter[],
  clearOld: boolean = false
): Promise<{
  success: boolean;
  count: number;
}> {
  try {
    // If clearOld requested or roster is empty, purge stale voter tokens first
    if (clearOld || voters.length === 0) {
      const snap = await getDocs(collection(db, 'voter_tokens'));
      if (!snap.empty) {
        const docs = snap.docs;
        for (let i = 0; i < docs.length; i += 400) {
          const batch = writeBatch(db);
          const chunk = docs.slice(i, i + 400);
          chunk.forEach((d) => batch.delete(d.ref));
          await batch.commit();
        }
      }
    }

    if (voters.length === 0) {
      return { success: true, count: 0 };
    }

    // Write in batches of up to 400 documents
    const batchSize = 400;
    let processed = 0;

    for (let i = 0; i < voters.length; i += batchSize) {
      const chunk = voters.slice(i, i + batchSize);
      const batch = writeBatch(db);

      for (const voter of chunk) {
        const cleanId = voter.voterId.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '_');
        const tokenRef = doc(db, 'voter_tokens', `token-${cleanId}`);
        batch.set(
          tokenRef,
          {
            id: `token-${cleanId}`,
            voterId: voter.voterId.trim().toUpperCase(),
            token: voter.pin || 'N/A',
            fullName: voter.fullName,
            hasVoted: !!voter.hasVoted,
            votedAt: voter.votedAt || null,
            status: voter.hasVoted ? 'used' : 'active',
            issuedAt: new Date().toISOString(),
          },
          { merge: true }
        );
      }

      await batch.commit();
      processed += chunk.length;
    }

    return { success: true, count: processed };
  } catch (error) {
    console.error('[Firebase] Failed to batch sync voter tokens to Firestore:', error);
    return { success: false, count: 0 };
  }
}

/**
 * Fetches the voter tokens once on demand using standard getDocs (to save read quota).
 */
export async function fetchVoterTokensOnce(): Promise<VoterTokenRecord[]> {
  try {
    const tokensQuery = query(collection(db, 'voter_tokens'));
    const snapshot = await getDocs(tokensQuery);
    const tokens: VoterTokenRecord[] = [];
    snapshot.forEach((docSnap) => {
      tokens.push(docSnap.data() as VoterTokenRecord);
    });
    return tokens;
  } catch (error) {
    console.error('[Firebase] Failed to fetch voter tokens on-demand:', error);
    return [];
  }
}

/**
 * Fetches anonymous votes once on demand using standard getDocs.
 */
export async function fetchAnonymousVotesOnce(): Promise<Ballot[]> {
  try {
    const votesQuery = query(collection(db, 'votes'), orderBy('submittedAt', 'asc'));
    const snapshot = await getDocs(votesQuery);
    const ballots: Ballot[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      ballots.push({
        id: data.id || docSnap.id,
        choices: data.choices || {},
        submittedAt: data.submittedAt || new Date().toISOString(),
        isPractice: !!data.isPractice,
        evidenceHash: data.evidenceHash || undefined,
      });
    });
    return ballots;
  } catch (error) {
    console.error('[Firebase] Failed to fetch votes on-demand:', error);
    return [];
  }
}

/**
 * Real-time listener on the Firestore 'votes' collection.
 * Triggers callback immediately on subscription and whenever a new anonymous vote is deposited.
 */
export function subscribeToAnonymousVotes(
  onVotesUpdate: (ballots: Ballot[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  try {
    const votesQuery = query(collection(db, 'votes'), orderBy('submittedAt', 'asc'));
    return onSnapshot(
      votesQuery,
      (snapshot) => {
        const ballots: Ballot[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          ballots.push({
            id: data.id || docSnap.id,
            choices: data.choices || {},
            submittedAt: data.submittedAt || new Date().toISOString(),
            isPractice: !!data.isPractice,
            evidenceHash: data.evidenceHash || undefined,
          });
        });
        onVotesUpdate(ballots);
      },
      (err) => {
        // Soft fallback for offline/reconnecting states
        onError?.(err);
      }
    );
  } catch (err: any) {
    onError?.(err);
    return () => {};
  }
}

/**
 * Real-time listener on the Firestore 'voter_tokens' collection.
 */
export function subscribeToVoterTokens(
  onTokensUpdate: (tokens: VoterTokenRecord[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  try {
    const tokensQuery = query(collection(db, 'voter_tokens'));
    return onSnapshot(
      tokensQuery,
      (snapshot) => {
        const tokens: VoterTokenRecord[] = [];
        snapshot.forEach((docSnap) => {
          tokens.push(docSnap.data() as VoterTokenRecord);
        });
        onTokensUpdate(tokens);
      },
      (err) => {
        // Soft fallback for offline/reconnecting states
        onError?.(err);
      }
    );
  } catch (err: any) {
    onError?.(err);
    return () => {};
  }
}

/**
 * Real-time listener on the Firestore 'agent_monitoring' collection.
 */
export function subscribeToAgentMonitoring(
  onAgentsUpdate: (agents: AgentObserverRecord[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  try {
    const agentsQuery = query(collection(db, 'agent_monitoring'));
    return onSnapshot(
      agentsQuery,
      (snapshot) => {
        const agents: AgentObserverRecord[] = [];
        snapshot.forEach((docSnap) => {
          agents.push(docSnap.data() as AgentObserverRecord);
        });
        onAgentsUpdate(agents);
      },
      (err) => {
        // Soft fallback for offline/reconnecting states
        onError?.(err);
      }
    );
  } catch (err: any) {
    onError?.(err);
    return () => {};
  }
}

/**
 * Registers or sends a heartbeat ping for a live observer / candidate agent.
 */
export async function registerOrPingAgent(agent: AgentObserverRecord): Promise<boolean> {
  try {
    const agentRef = doc(db, 'agent_monitoring', agent.id);
    await setDoc(agentRef, {
      ...agent,
      lastHeartbeat: new Date().toISOString(),
    });
    return true;
  } catch (error) {
    console.error('[Firebase] Failed to register or ping agent:', error);
    return false;
  }
}

/**
 * Helper to race a promise with a timeout so Firestore operations never hang
 */
function withTimeout<T>(promise: Promise<T>, timeoutMs: number, fallback: T): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((resolve) => setTimeout(() => resolve(fallback), timeoutMs)),
  ]);
}

/**
 * Purges all ballots in the Firestore 'votes' collection.
 * Used to reset the live ballot box without deleting roster or candidates.
 */
export async function clearAllFirestoreVotes(): Promise<boolean> {
  try {
    const doClearVotes = async () => {
      const snap = await getDocs(collection(db, 'votes'));
      if (!snap.empty) {
        const docs = snap.docs;
        for (let i = 0; i < docs.length; i += 400) {
          const batch = writeBatch(db);
          const chunk = docs.slice(i, i + 400);
          chunk.forEach((d) => batch.delete(d.ref));
          await batch.commit();
        }
      }
      return true;
    };
    await withTimeout(doClearVotes(), 2500, false);
    return true;
  } catch (error) {
    console.warn('[Firebase] Non-fatal clear votes warning:', error);
    return true;
  }
}

/**
 * Completely purges all votes, voter tokens, and agent monitoring telemetry from Firestore
 * to make room for a completely fresh selection setup.
 */
export async function clearAllFirestoreElectionData(
  preservedAccounts?: any[]
): Promise<{ success: boolean; error?: string }> {
  try {
    const doClear = async () => {
      const collectionsToClear = ['votes', 'voter_tokens', 'agent_monitoring'];
      for (const collName of collectionsToClear) {
        try {
          const snap = await getDocs(collection(db, collName));
          if (!snap.empty) {
            const docs = snap.docs;
            for (let i = 0; i < docs.length; i += 400) {
              const batch = writeBatch(db);
              const chunk = docs.slice(i, i + 400);
              chunk.forEach((d) => batch.delete(d.ref));
              await batch.commit();
            }
          }
        } catch (colErr) {
          console.warn(`[Firebase] Non-fatal clear error for ${collName}:`, colErr);
        }
      }

      // Reset election metadata to fresh setup
      try {
        const metaRef = doc(db, 'election_metadata', 'current');
        await setDoc(metaRef, {
          status: 'Setup',
          config: {
            id: 'config-' + Date.now(),
            title: 'New Student Election',
            schoolName: 'Our School',
            logoUrl: '',
            date: new Date().toISOString().split('T')[0],
            requirePin: true,
            adminPin: 'admin123',
            hideTalliesDuringVoting: true,
            allowPracticeBallot: true,
            showClockToVoters: true,
            enableCaptcha: true,
            closingTime: '20:00',
          },
          positions: [],
          candidates: [],
          voters: [],
          totalEligibleVoters: 0,
          accounts: preservedAccounts || [],
          lastUpdated: new Date().toISOString(),
          updatedBy: 'System Clear',
        });
      } catch (metaErr) {
        console.warn('[Firebase] Could not reset election_metadata document:', metaErr);
      }
    };

    await withTimeout(doClear(), 2500, null);
    return { success: true };
  } catch (error: any) {
    console.warn('[Firebase] Non-fatal clear error:', error);
    return { success: true };
  }
}

/**
 * Safely sanitizes an object for Firestore by removing undefined values and circular references.
 */
function sanitizeForFirestore<T>(data: T): T {
  return JSON.parse(JSON.stringify(data));
}

/**
 * Saves or transitions election status (Setup, Open, Closed, Results Published) in Firestore.
 * This guarantees any device or refreshed browser across Netlify / mobile immediately knows polls are Open.
 */
export async function saveElectionStatusToFirestore(
  status: ElectionStatus,
  updatedBy: string = 'Admin'
): Promise<boolean> {
  try {
    const metaRef = doc(db, 'election_metadata', 'current');
    const updateTask = setDoc(
      metaRef,
      sanitizeForFirestore({
        status,
        lastUpdated: new Date().toISOString(),
        updatedBy,
      }),
      { merge: true }
    );
    await withTimeout(updateTask, 2500, null);
    return true;
  } catch (err) {
    console.warn('[Firebase] Failed to save election status to Firestore:', err);
    return false;
  }
}

/**
 * Saves canonical election configuration, positions, candidates, and voter roster into Firestore.
 * Allows other devices on Netlify to fetch the exact same configuration as the Commissioner.
 */
export async function saveElectionStateToFirestore(
  data: Partial<ElectionData>,
  status?: ElectionStatus,
  updatedBy: string = 'Admin'
): Promise<boolean> {
  try {
    const metaRef = doc(db, 'election_metadata', 'current');
    const payload: Record<string, any> = {
      lastUpdated: new Date().toISOString(),
      updatedBy,
    };

    if (status) payload.status = status;
    if (data.config) payload.config = data.config;
    if (data.positions !== undefined) payload.positions = data.positions;
    if (data.candidates !== undefined) payload.candidates = data.candidates;
    if (data.voters !== undefined) {
      payload.voters = data.voters;
      payload.totalEligibleVoters = data.voters.length;
    }
    if (data.accounts !== undefined) payload.accounts = data.accounts;

    const saveTask = setDoc(metaRef, sanitizeForFirestore(payload), { merge: true });
    await withTimeout(saveTask, 2500, null);

    return true;
  } catch (err) {
    console.warn('[Firebase] Failed to save election state to Firestore:', err);
    return false;
  }
}

/**
 * Reads canonical election metadata (status, config, positions, candidates, voters) from Firestore.
 */
export async function getElectionMetadataFromFirestore(): Promise<{
  status?: ElectionStatus;
  config?: any;
  positions?: any[];
  candidates?: any[];
  voters?: any[];
  accounts?: any[];
  totalEligibleVoters?: number;
  lastUpdated?: string;
} | null> {
  const metaRef = doc(db, 'election_metadata', 'current');
  try {
    const snap = await getDoc(metaRef);
    if (snap.exists()) {
      return snap.data() as any;
    }
    return null;
  } catch {
    // If offline or network unavailable, seamlessly retrieve from local persistent cache
    try {
      const cacheSnap = await getDocFromCache(metaRef);
      if (cacheSnap.exists()) {
        return cacheSnap.data() as any;
      }
    } catch {
      // Local cache empty or pending
    }
    return null;
  }
}

/**
 * Real-time listener on the Firestore 'election_metadata/current' document.
 * When status transitions from Setup -> Open on Commissioner's device,
 * all voter booths on Netlify / other devices instantly receive the update.
 */
export function subscribeToElectionMetadata(
  onMetadataUpdate: (metadata: {
    status?: ElectionStatus;
    config?: any;
    positions?: any[];
    candidates?: any[];
    voters?: any[];
    accounts?: any[];
    lastUpdated?: string;
  }) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  try {
    const metaRef = doc(db, 'election_metadata', 'current');
    return onSnapshot(
      metaRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          onMetadataUpdate({
            status: data.status,
            config: data.config,
            positions: data.positions,
            candidates: data.candidates,
            voters: data.voters,
            accounts: data.accounts,
            lastUpdated: data.lastUpdated,
          });
        }
      },
      (err) => {
        // Soft fallback for offline/reconnecting states
        onError?.(err);
      }
    );
  } catch (err: any) {
    onError?.(err);
    return () => {};
  }
}


